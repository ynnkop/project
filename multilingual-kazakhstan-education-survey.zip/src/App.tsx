import { useState, useCallback, useEffect } from "react";

// ===================== TYPES =====================
type Lang = "ru" | "kk" | "en";

interface Translations {
  [key: string]: { ru: string; kk: string; en: string } | undefined;
}

// ===================== TRANSLATIONS =====================
const t: Translations = {
  // Welcome screen
  welcomeTitle: {
    ru: "Білім жолы — Путь образования",
    kk: "Білім жолы — Образование жолы",
    en: "Education Path Survey",
  },
  welcomeSubtitle: {
    ru: "Опрос о вашем образовательном пути и предпочтениях в Казахстане",
    kk: "Қазақстандағы білім беру жолы мен таңдауларыңыз туралы сұрау",
    en: "Survey about your educational path and preferences in Kazakhstan",
  },
  welcomeRu: {
    ru: "Добро пожаловать! Этот опрос поможет нам лучше понять ваш образовательный опыт в Казахстане. Ответы анонимны.",
    kk: "Қош келдіңіз! Бұл сұрау бізге Сіздің Қазақстандағы білім беру тәжірибеніңізді жақсы түсіндіруге көмектеседі. Жауаптар анонимді.",
    en: "Welcome! This survey will help us better understand your educational experience in Kazakhstan. Responses are anonymous.",
  },
  chooseLang: {
    ru: "Выберите язык опроса:",
    kk: "Сұрау тілін таңдаңыз:",
    en: "Choose your survey language:",
  },
  startSurvey: {
    ru: "Начать опрос",
    kk: "Сұрауды бастау",
    en: "Start Survey",
  },

  // Section headers
  sectionAdmission: {
    ru: "Поступление",
    kk: "Оқуға түсу",
    en: "Admission",
  },

  sectionExams: {
    ru: "Экзамены",
    kk: "Емтихандар",
    en: "Exams",
  },

  // Questions
  q1: {
    ru: "Какой город для поступления вас интересует?",
    kk: "Оқуға түсу үшін қандай қала қызықтырады?",
    en: "Which city are you interested in for admission?",
  },
  q2: {
    ru: "На каком языке вы хотите проходить обучение?",
    kk: "Қандай тілде оқығыңыз келеді?",
    en: "In which language would you like to study?",
  },
  q3: {
    ru: "На какую специальность вы будете поступать?",
    kk: "Қандай мамандыққа түсесіз?",
    en: "What specialty will you apply for?",
  },
  q4: {
    ru: "Какие экзамены вы планируете сдавать для поступления?",
    kk: "Оқуға түсу үшін қандай емтихандар тапсыруды жоспарлайсыз?",
    en: "Which exams do you plan to take for admission?",
  },

  // Thank you
  thankYou: {
    ru: "Спасибо за участие в опросе!",
    kk: "Сұрауға қатысқаныңыз үшін рахмет!",
    en: "Thank you for participating in the survey!",
  },
  thankYouSub: {
    ru: "Ваш ответ поможет нам создать лучшие предложения для вас.",
    kk: "Сіздің жауабыңыз бізге сіз үшін жақсы ұсыныстар жасауға көмектеседі.",
    en: "Your response will help us create better offers for you.",
  },
  retake: {
    ru: "Пройти опрос заново",
    kk: "Сұрауды қайта бастау",
    en: "Retake Survey",
  },

  // Navigation
  next: { ru: "Далее", kk: "Келесі", en: "Next" },
  back: { ru: "Назад", kk: "Артқа", en: "Back" },
  submit: { ru: "Отправить", kk: "Жіберу", en: "Submit" },
  other: { ru: "Другое", kk: "Басқа", en: "Other" },
  otherPlaceholder: {
    ru: "Введите свой вариант...",
    kk: "Өз нұсқаңызды енгізіңіз...",
    en: "Enter your option...",
  },
  stepOf: { ru: "из", kk: "/", en: "of" },
  progress: { ru: "Прогресс", kk: "Барысы", en: "Progress" },
};

// Helper to get translation
function tr(key: string, lang: Lang): string {
  return (t[key] as Record<string, string>)?.[lang] || key;
}

// ===================== OPTIONS DATA =====================
interface Option {
  id: string;
  ru: string;
  kk: string;
  en: string;
}

const admissionCityOptions: Option[] = [
  { id: "almaty", ru: "Алматы", kk: "Алматы", en: "Almaty" },
  { id: "astana", ru: "Астана", kk: "Астана", en: "Astana" },
  { id: "shymkent", ru: "Шымкент", kk: "Шымкент", en: "Shymkent" },
  { id: "karaganda", ru: "Караганда", kk: "Қарағанды", en: "Karaganda" },
  { id: "aktobe", ru: "Актобе", kk: "Ақтөбе", en: "Aktobe" },
  { id: "pavlodar", ru: "Павлодар", kk: "Павлодар", en: "Pavlodar" },
  { id: "semey", ru: "Семей", kk: "Семей", en: "Semey" },
  { id: "other", ru: "Другой город", kk: "Басқа қала", en: "Other city" },
];

const languageOptions: Option[] = [
  { id: "russian", ru: "Русский", kk: "Орыс тілі", en: "Russian" },
  { id: "kazakh", ru: "Казахский", kk: "Қазақ тілі", en: "Kazakh" },
  { id: "english", ru: "Английский", kk: "Ағылшын тілі", en: "English" },
];

const specialtyAdmissionOptions: Option[] = [
  { id: "oilgas", ru: "Нефтегазовое дело", kk: "Мұнай-газ ісі", en: "Oil & Gas" },
  { id: "it", ru: "Информационные технологии", kk: "Ақпараттық технологиялар", en: "Information Technology (IT)" },
  { id: "medicine", ru: "Медицина", kk: "Медицина", en: "Medicine" },
  { id: "economics", ru: "Экономика и финансы", kk: "Экономика және қаржы", en: "Economics & Finance" },
  { id: "pedagogy", ru: "Педагогика", kk: "Педагогика", en: "Pedagogy" },
  { id: "law", ru: "Юриспруденция", kk: "Құқықтану", en: "Law / Jurisprudence" },
  { id: "engineering", ru: "Инженерия", kk: "Инженерия", en: "Engineering" },
  { id: "agrotech", ru: "Агротехника", kk: "Агротехника", en: "Agrotech" },
  { id: "other", ru: "Другое", kk: "Басқа", en: "Other" },
];

const examOptions: Option[] = [
  { id: "ielts", ru: "IELTS", kk: "IELTS", en: "IELTS" },
  { id: "sat", ru: "SAT", kk: "SAT", en: "SAT" },
  { id: "nuet", ru: "NUET (НУЭТ)", kk: "NUET (НУЭТ)", en: "NUET" },
  { id: "ent", ru: "ЕНТ / Единый национальный тест", kk: "ҰБТ / Ұлттық бірыңғай тест", en: "ENT / Unified National Test" },
  { id: "none", ru: "Пока не определился(лась)", kk: "Әлі шешкен жоқпын", en: "Haven't decided yet" },
  { id: "other", ru: "Другое", kk: "Басқа", en: "Other" },
];

// ===================== QUESTION CONFIG =====================
interface QuestionConfig {
  key: string;
  section: string;
  type: "single" | "multi";
  options: Option[];
  hasOtherText: boolean;
}

const questions: QuestionConfig[] = [
  { key: "admission_city", section: "sectionAdmission", type: "single", options: admissionCityOptions, hasOtherText: false },
  { key: "study_language", section: "sectionAdmission", type: "single", options: languageOptions, hasOtherText: false },
  { key: "specialty_admission", section: "sectionAdmission", type: "multi", options: specialtyAdmissionOptions, hasOtherText: true },
  { key: "exams", section: "sectionExams", type: "multi", options: examOptions, hasOtherText: false },
];

const TOTAL_QUESTIONS = questions.length;

// ===================== KAZAKH ORNAMENT SVG =====================
function KazakhOrnament({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 200 30" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M0 15 L10 5 L20 15 L30 5 L40 15 L50 5 L60 15 L70 5 L80 15 L90 5 L100 15 L110 5 L120 15 L130 5 L140 15 L150 5 L160 15 L170 5 L180 15 L190 5 L200 15"
        stroke="currentColor"
        strokeWidth="1.5"
        opacity="0.3"
      />
      <circle cx="0" cy="15" r="2" fill="currentColor" opacity="0.2" />
      <circle cx="50" cy="15" r="2" fill="currentColor" opacity="0.2" />
      <circle cx="100" cy="15" r="2" fill="currentColor" opacity="0.2" />
      <circle cx="150" cy="15" r="2" fill="currentColor" opacity="0.2" />
      <circle cx="200" cy="15" r="2" fill="currentColor" opacity="0.2" />
    </svg>
  );
}

// ===================== SHANYRAK SVG =====================
function ShanyrakIcon({ size = 48 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Top circle - sun */}
      <circle cx="50" cy="30" r="12" stroke="#FFD700" strokeWidth="2" fill="none" />
      <circle cx="50" cy="30" r="6" fill="#FFD700" opacity="0.4" />
      {/* Shanyrak dome */}
      <path d="M20 55 Q50 25 80 55" stroke="#0077BE" strokeWidth="2.5" fill="none" />
      {/* Cross beams */}
      <line x1="50" y1="30" x2="50" y2="70" stroke="#0077BE" strokeWidth="2" />
      <line x1="25" y1="55" x2="75" y2="55" stroke="#0077BE" strokeWidth="2" />
      {/* Lower frame */}
      <line x1="30" y1="55" x2="20" y2="75" stroke="#0077BE" strokeWidth="2" />
      <line x1="70" y1="55" x2="80" y2="75" stroke="#0077BE" strokeWidth="2" />
      <line x1="20" y1="75" x2="80" y2="75" stroke="#0077BE" strokeWidth="2" />
      {/* Decorative elements */}
      <circle cx="35" cy="48" r="2" fill="#FFD700" />
      <circle cx="65" cy="48" r="2" fill="#FFD700" />
      <circle cx="50" cy="42" r="2" fill="#FFD700" />
    </svg>
  );
}

// ===================== BAITEREK SVG =====================
function BaiterekIcon({ size = 80 }: { size?: number }) {
  return (
    <svg width={size} height={size * 1.4} viewBox="0 0 100 140" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Base */}
      <ellipse cx="50" cy="130" rx="30" ry="5" fill="#0077BE" opacity="0.1" />
      {/* Main column */}
      <rect x="46" y="50" width="8" height="80" rx="2" fill="#0077BE" opacity="0.7" />
      {/* Top sphere */}
      <circle cx="50" cy="35" r="15" stroke="#FFD700" strokeWidth="2" fill="#FFD700" opacity="0.15" />
      <circle cx="50" cy="35" r="10" stroke="#FFD700" strokeWidth="1.5" fill="#FFD700" opacity="0.2" />
      <circle cx="50" cy="35" r="4" fill="#FFD700" opacity="0.5" />
      {/* Branches */}
      <path d="M46 65 Q30 55 20 40" stroke="#0077BE" strokeWidth="2" fill="none" opacity="0.5" />
      <path d="M54 65 Q70 55 80 40" stroke="#0077BE" strokeWidth="2" fill="none" opacity="0.5" />
      <path d="M46 75 Q35 70 25 60" stroke="#0077BE" strokeWidth="1.5" fill="none" opacity="0.4" />
      <path d="M54 75 Q65 70 75 60" stroke="#0077BE" strokeWidth="1.5" fill="none" opacity="0.4" />
      {/* Small decorations on branches */}
      <circle cx="20" cy="40" r="3" fill="#0077BE" opacity="0.3" />
      <circle cx="80" cy="40" r="3" fill="#0077BE" opacity="0.3" />
      <circle cx="25" cy="60" r="2.5" fill="#0077BE" opacity="0.25" />
      <circle cx="75" cy="60" r="2.5" fill="#0077BE" opacity="0.25" />
    </svg>
  );
}

// ===================== MOUNTAIN BG =====================
function MountainBackground() {
  return (
    <svg
      className="mountain-bg"
      viewBox="0 0 1440 120"
      preserveAspectRatio="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M0 120 L0 80 L120 40 L240 70 L360 20 L480 60 L600 10 L720 50 L840 30 L960 55 L1080 15 L1200 45 L1320 25 L1440 60 L1440 120 Z" fill="#0077BE" />
      <path d="M0 120 L0 90 L180 60 L360 80 L540 50 L720 70 L900 45 L1080 65 L1260 55 L1440 75 L1440 120 Z" fill="#0077BE" opacity="0.5" />
    </svg>
  );
}

// ===================== LANGUAGE SWITCHER =====================
function LanguageSwitcher({
  lang,
  setLang,
  minimal = false,
}: {
  lang: Lang;
  setLang: (l: Lang) => void;
  minimal?: boolean;
}) {
  const langs: { code: Lang; flag: string; label: string; short: string }[] = [
    { code: "ru", flag: "🇷🇺", label: "Русский", short: "RU" },
    { code: "kk", flag: "🇰🇿", label: "Қазақша", short: "KZ" },
    { code: "en", flag: "🇬🇧", label: "English", short: "EN" },
  ];

  return (
    <div className={`flex gap-2 ${minimal ? "" : ""}`}>
      {langs.map((l) => (
        <button
          key={l.code}
          onClick={() => setLang(l.code)}
          className={`
            flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium
            transition-all duration-200 border border-transparent
            ${
              lang === l.code
                ? "lang-btn-active"
                : "lang-btn-inactive hover:border-kz-blue/30"
            }
          `}
          title={l.label}
        >
          <span className="text-base">{l.flag}</span>
          <span className="hidden sm:inline">{minimal ? l.short : l.short}</span>
        </button>
      ))}
    </div>
  );
}

// ===================== PROGRESS BAR =====================
function ProgressBar({ current, total, lang }: { current: number; total: number; lang: Lang }) {
  const pct = ((current) / total) * 100;
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1.5">
        <span className="text-xs text-gray-500 font-medium">{tr("progress", lang)}</span>
        <span className="text-xs text-kz-blue font-semibold">
          {current} {tr("stepOf", lang)} {total}
        </span>
      </div>
      <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="progress-fill h-full rounded-full"
          style={{
            width: `${pct}%`,
            background: "linear-gradient(90deg, #0077BE, #0099E6, #0077BE)",
          }}
        />
      </div>
    </div>
  );
}

// ===================== OPTION CARD =====================
function OptionCard({
  option,
  selected,
  onSelect,
  type,
  lang,
}: {
  option: Option;
  selected: boolean;
  onSelect: () => void;
  type: "single" | "multi";
  lang: Lang;
}) {
  return (
    <div
      onClick={onSelect}
      className={`
        option-card flex items-center gap-3 p-3.5 rounded-xl border-2 
        ${selected ? "selected border-kz-blue bg-kz-blue-light" : "border-gray-200 bg-white hover:border-kz-blue/40"}
      `}
    >
      {type === "single" ? (
        <div
          className={`
            w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center
            transition-all duration-200
            ${selected ? "border-kz-blue bg-kz-blue" : "border-gray-400"}
          `}
        >
          {selected && <div className="w-2 h-2 rounded-full bg-white" />}
        </div>
      ) : (
        <div
          className={`
            w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center
            transition-all duration-200
            ${selected ? "border-kz-blue bg-kz-blue" : "border-gray-400"}
          `}
        >
          {selected && (
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M2 6L5 9L10 3" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
      )}
      <span className={`text-sm ${selected ? "text-kz-blue font-medium" : "text-gray-700"}`}>
        {option[lang]}
      </span>
    </div>
  );
}

// ===================== WELCOME SCREEN =====================
function WelcomeScreen({ lang, setLang, onStart }: { lang: Lang; setLang: (l: Lang) => void; onStart: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-12px)] px-4 py-8 relative z-10 fade-in">
      {/* Ornament top */}
      <KazakhOrnament className="w-64 text-kz-blue mb-6" />

      {/* Shanyrak icon */}
      <ShanyrakIcon size={72} />

      {/* Title */}
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-kz-blue mt-6 mb-3 text-center tracking-tight">
        {tr("welcomeTitle", lang)}
      </h1>

      {/* Subtitle */}
      <p className="text-base sm:text-lg text-gray-600 max-w-xl text-center mb-8 leading-relaxed">
        {tr("welcomeSubtitle", lang)}
      </p>

      {/* Welcome card */}
      <div className="glass-card rounded-2xl shadow-xl border border-kz-blue/10 p-6 sm:p-8 max-w-lg w-full">
        {/* Language description */}
        <p className="text-gray-700 text-center mb-6 leading-relaxed">
          {tr("welcomeRu", lang)}
        </p>

        {/* Choose language */}
        <p className="text-center text-sm font-semibold text-kz-blue mb-4 uppercase tracking-wide">
          {tr("chooseLang", lang)}
        </p>

        {/* Language buttons */}
        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          {[
            { code: "ru" as Lang, flag: "🇷🇺", name: "Русский", desc: "Russian" },
            { code: "kk" as Lang, flag: "🇰🇿", name: "Қазақша", desc: "Kazakh" },
            { code: "en" as Lang, flag: "🇬🇧", name: "English", desc: "English" },
          ].map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code)}
              className={`
                flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border-2 
                transition-all duration-200 text-sm font-semibold
                ${
                  lang === l.code
                    ? "border-kz-blue bg-kz-blue text-white shadow-lg shadow-kz-blue/20"
                    : "border-gray-200 bg-white text-gray-700 hover:border-kz-blue/40 hover:bg-kz-blue-light"
                }
              `}
            >
              <span className="text-xl">{l.flag}</span>
              <span>{l.name}</span>
            </button>
          ))}
        </div>

        {/* Start button */}
        <button
          onClick={onStart}
          className="w-full py-4 bg-kz-blue text-white font-bold text-lg rounded-xl
            hover:bg-kz-blue-dark transition-all duration-200 shadow-lg shadow-kz-blue/25
            hover:shadow-xl hover:shadow-kz-blue/30 active:scale-[0.98] btn-pulse"
        >
          {tr("startSurvey", lang)} →
        </button>
      </div>

      {/* Baiterek decoration */}
      <div className="mt-8 opacity-20">
        <BaiterekIcon size={50} />
      </div>

      {/* Ornament bottom */}
      <KazakhOrnament className="w-64 text-kz-blue mt-6" />
    </div>
  );
}

// ===================== QUESTION SCREEN =====================
function QuestionScreen({
  step,
  lang,
  answers,
  otherTexts,
  setAnswers,
  setOtherTexts,
  onNext,
  onBack,
  onSubmit,
}: {
  step: number;
  lang: Lang;
  answers: Record<string, string[]>;
  otherTexts: Record<string, string>;
  setAnswers: React.Dispatch<React.SetStateAction<Record<string, string[]>>>;
  setOtherTexts: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  onNext: () => void;
  onBack: () => void;
  onSubmit: () => void;
}) {
  const q = questions[step];
  const isLast = step === TOTAL_QUESTIONS - 1;
  const sectionName = tr(q.section, lang);
  const questionText = tr(`q${step + 1}`, lang);

  const currentAnswers = answers[q.key] || [];
  const hasSelection = currentAnswers.length > 0;
  const hasOther = currentAnswers.includes("other");
  const otherValue = otherTexts[q.key] || "";

  const handleSelect = useCallback(
    (optionId: string) => {
      setAnswers((prev) => {
        const prevArr = prev[q.key] || [];
        if (q.type === "single") {
          return { ...prev, [q.key]: [optionId] };
        } else {
          // Multi-select
          if (prevArr.includes(optionId)) {
            return { ...prev, [q.key]: prevArr.filter((x) => x !== optionId) };
          } else {
            return { ...prev, [q.key]: [...prevArr, optionId] };
          }
        }
      });
    },
    [q.key, q.type, setAnswers]
  );

  const sectionIndex = questions.findIndex((qq) => qq.section === q.section);
  const showSectionHeader = step === sectionIndex;

  return (
    <div className="flex flex-col min-h-[calc(100vh-12px)] relative z-10">
      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-6">
        <div className="w-full max-w-2xl slide-in" key={`q-${step}-${lang}`}>
          {/* Section header */}
          {showSectionHeader && (
            <div className="flex items-center gap-3 mb-4">
              <div className="w-1 h-6 bg-kz-gold rounded-full" />
              <h3 className="text-xs font-bold text-kz-gold uppercase tracking-widest">
                {sectionName}
              </h3>
            </div>
          )}

          {/* Question */}
          <h2 className="text-xl sm:text-2xl font-bold text-kz-text mb-6 leading-snug">
            {questionText}
          </h2>

          {/* Type hint */}
          {q.type === "multi" && (
            <p className="text-xs text-gray-400 mb-4 italic">
              {lang === "ru" && "Можно выбрать несколько вариантов"}
              {lang === "kk" && "Бірнеше нұсқаны таңдауға болады"}
              {lang === "en" && "You can select multiple options"}
            </p>
          )}

          {/* Options */}
          <div className="flex flex-col gap-2.5 mb-4">
            {q.options.map((opt) => (
              <OptionCard
                key={opt.id}
                option={opt}
                selected={currentAnswers.includes(opt.id)}
                onSelect={() => handleSelect(opt.id)}
                type={q.type}
                lang={lang}
              />
            ))}
          </div>

          {/* Other text input */}
          {q.hasOtherText && hasOther && (
            <div className="mt-3 fade-in">
              <input
                type="text"
                value={otherValue}
                onChange={(e) => setOtherTexts((prev) => ({ ...prev, [q.key]: e.target.value }))}
                placeholder={tr("otherPlaceholder", lang)}
                className="w-full px-4 py-3 rounded-xl border-2 border-kz-blue/30 bg-white
                  text-gray-700 text-sm focus:outline-none focus:border-kz-blue focus:ring-2 focus:ring-kz-blue/20
                  transition-all duration-200"
              />
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <div className="sticky bottom-6 px-4 pb-4 z-20">
        <div className="max-w-2xl mx-auto flex gap-3">
          {step > 0 && (
            <button
              onClick={onBack}
              className="px-6 py-3 rounded-xl border-2 border-gray-300 text-gray-600 font-semibold
                hover:bg-gray-50 transition-all duration-200 active:scale-[0.97]"
            >
              ← {tr("back", lang)}
            </button>
          )}
          <div className="flex-1" />
          <button
            onClick={isLast ? onSubmit : onNext}
            disabled={!hasSelection}
            className={`
              px-8 py-3 rounded-xl font-semibold transition-all duration-200 active:scale-[0.97]
              ${
                hasSelection
                  ? "bg-kz-blue text-white hover:bg-kz-blue-dark shadow-lg shadow-kz-blue/25 hover:shadow-xl"
                  : "bg-gray-200 text-gray-400 cursor-not-allowed"
              }
            `}
          >
            {isLast ? (
              <>
                {tr("submit", lang)} ✓
              </>
            ) : (
              <>
                {tr("next", lang)} →
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ===================== THANK YOU SCREEN =====================
function ThankYouScreen({
  lang,
  onRetake,
}: {
  lang: Lang;
  onRetake: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-12px)] px-4 py-8 relative z-10 fade-in">
      {/* Confetti pieces */}
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="confetti-piece"
          style={{
            left: `${Math.random() * 100}%`,
            backgroundColor: ["#0077BE", "#FFD700", "#6B8E6B", "#0099E6", "#F5E6C8"][i % 5],
            width: `${6 + Math.random() * 8}px`,
            height: `${6 + Math.random() * 8}px`,
            borderRadius: i % 3 === 0 ? "50%" : "2px",
            animation: `confetti ${2 + Math.random() * 3}s linear ${Math.random() * 2}s infinite`,
          }}
        />
      ))}

      <KazakhOrnament className="w-64 text-kz-gold mb-6" />

      {/* Success icon */}
      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-kz-blue to-kz-blue-dark flex items-center justify-center shadow-2xl shadow-kz-blue/30 mb-8">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
          <path d="M12 24L20 32L36 16" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-kz-blue mb-4 text-center">
        {tr("thankYou", lang)}
      </h1>

      <p className="text-base sm:text-lg text-gray-600 max-w-md text-center mb-10 leading-relaxed">
        {tr("thankYouSub", lang)}
      </p>

      {/* Shanyrak */}
      <ShanyrakIcon size={56} />

      <button
        onClick={onRetake}
        className="mt-8 px-8 py-3 rounded-xl border-2 border-kz-blue text-kz-blue font-semibold
          hover:bg-kz-blue hover:text-white transition-all duration-200 active:scale-[0.97]"
      >
        {tr("retake", lang)}
      </button>

      <KazakhOrnament className="w-64 text-kz-gold mt-8" />
    </div>
  );
}

// ===================== MAIN APP =====================
export default function App() {
  const [lang, setLang] = useState<Lang>("ru");
  const [step, setStep] = useState(-1); // -1 = welcome
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [otherTexts, setOtherTexts] = useState<Record<string, string>>({});

  const handleStart = useCallback(() => {
    setStep(0);
  }, []);

  const handleNext = useCallback(() => {
    setStep((s) => Math.min(s + 1, TOTAL_QUESTIONS - 1));
  }, []);

  const handleBack = useCallback(() => {
    setStep((s) => Math.max(s - 1, 0));
  }, []);

  const handleSubmit = useCallback(() => {
    // Log answers (in real app, send to server)
    console.log("Survey answers:", answers);
    console.log("Other texts:", otherTexts);
    setStep(TOTAL_QUESTIONS); // thank you screen
  }, [answers, otherTexts]);

  const handleRetake = useCallback(() => {
    setAnswers({});
    setOtherTexts({});
    setStep(-1);
  }, []);

  // Scroll to top on step change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [step]);

  return (
    <div className="min-h-screen bg-pattern relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #E8F4FD 0%, #F0F7FF 25%, #FAFCFF 50%, #F5F0E8 75%, #EFF5EB 100%)",
      }}
    >
      {/* Top ornament bar */}
      <div className="ornament-top" />

      {/* Mountain background */}
      <MountainBackground />

      {/* Header with language switcher */}
      {step >= 0 && step < TOTAL_QUESTIONS && (
        <header className="fixed top-1.5 left-0 right-0 z-50 px-4 py-3">
          <div className="max-w-3xl mx-auto flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <ShanyrakIcon size={28} />
              <span className="text-sm font-bold text-kz-blue hidden sm:block">Білім жолы</span>
            </div>

            {/* Language switcher */}
            <LanguageSwitcher lang={lang} setLang={setLang} minimal />
          </div>
        </header>
      )}

      {/* Progress bar */}
      {step >= 0 && step < TOTAL_QUESTIONS && (
        <div className="fixed top-14 left-0 right-0 z-40 px-4 py-2">
          <div className="max-w-2xl mx-auto glass-card rounded-xl px-4 py-2.5 shadow-sm border border-kz-blue/10">
            <ProgressBar current={step + 1} total={TOTAL_QUESTIONS} lang={lang} />
          </div>
        </div>
      )}

      {/* Content */}
      <main className={step >= 0 && step < TOTAL_QUESTIONS ? "pt-28" : ""}>
        {step === -1 && (
          <WelcomeScreen lang={lang} setLang={setLang} onStart={handleStart} />
        )}
        {step >= 0 && step < TOTAL_QUESTIONS && (
          <QuestionScreen
            step={step}
            lang={lang}
            answers={answers}
            otherTexts={otherTexts}
            setAnswers={setAnswers}
            setOtherTexts={setOtherTexts}
            onNext={handleNext}
            onBack={handleBack}
            onSubmit={handleSubmit}
          />
        )}
        {step >= TOTAL_QUESTIONS && (
          <ThankYouScreen lang={lang} onRetake={handleRetake} />
        )}
      </main>

      {/* Bottom ornament bar */}
      <div className="ornament-bottom" />
    </div>
  );
}
